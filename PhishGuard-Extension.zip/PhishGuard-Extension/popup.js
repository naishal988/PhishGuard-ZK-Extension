document.addEventListener('DOMContentLoaded', function() {
    const PROD_API = "https://phishguard-backend-n7rj.onrender.com/api/scan";
    const urlInput = document.getElementById('url-input');
    const scanBtn = document.getElementById('scan-btn');
    const loader = document.getElementById('loader');
    const resultBox = document.getElementById('result-box');
    const resIcon = document.getElementById('res-icon');
    const resTitle = document.getElementById('res-title');
    const resReason = document.getElementById('res-reason');

    // Get current tab URL automatically
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if(tabs[0] && tabs[0].url) {
            urlInput.value = tabs[0].url;
        }
    });

    scanBtn.addEventListener('click', async () => {
        const urlToScan = urlInput.value.trim();
        if (!urlToScan) return;

        scanBtn.disabled = true;
        resultBox.style.display = "none";
        loader.style.display = "block";

        try {
            const response = await fetch(PROD_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url_to_scan: urlToScan })
            });
            
            const data = await response.json();
            loader.style.display = "none";
            resultBox.style.display = "block";

            if (data.is_phishing) {
                resultBox.className = "danger";
                resIcon.innerHTML = "☠️";
                resTitle.innerText = "THREAT DETECTED";
            } else {
                resultBox.className = "safe";
                resIcon.innerHTML = "✅";
                resTitle.innerText = "VERIFIED SAFE";
            }
            resReason.innerText = data.reason || data.error;

        } catch (error) {
            loader.style.display = "none";
            resultBox.style.display = "block";
            resultBox.className = "danger";
            resIcon.innerHTML = "❌";
            resTitle.innerText = "SCAN FAILED";
            resReason.innerText = "Could not connect to ZK Server.";
        } finally {
            scanBtn.disabled = false;
        }
    });
});