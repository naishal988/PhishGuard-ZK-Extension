const PROD_API = "https://phishguard-backend-n7rj.onrender.com/api/scan";

// Create right-click context menu
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "scanLinkZK",
        title: "🛡️ Scan link with PhishGuard ZK",
        contexts: ["link"]
    });
});

// Handle right-click action
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "scanLinkZK" && info.linkUrl) {
        chrome.notifications.create({
            type: "basic",
            iconUrl: "icon.png",
            title: "PhishGuard ZK",
            message: "Scanning link in background..."
        });

        fetch(PROD_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url_to_scan: info.linkUrl })
        })
        .then(response => response.json())
        .then(data => {
            let msg = data.is_phishing 
                ? "⚠️ DANGER: " + data.reason 
                : "✅ SAFE: This link looks clean.";
            
            chrome.notifications.create({
                type: "basic",
                iconUrl: "icon.png",
                title: data.is_phishing ? "Threat Detected!" : "Verified Safe",
                message: msg
            });
        })
        .catch(err => {
            chrome.notifications.create({
                type: "basic",
                iconUrl: "icon.png",
                title: "Scan Failed",
                message: "Could not connect to PhishGuard Server."
            });
        });
    }
});